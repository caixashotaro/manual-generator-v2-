@echo off
cd /d "%~dp0"
echo Starting the application...
start http://localhost:8501
python -m streamlit run app.py
pause
